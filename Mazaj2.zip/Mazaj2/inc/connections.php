<?php
 $conn = mysqli_connect('localhost','root','','Project1');
 if(!$conn){
    die('Error'.mysqli_connect_error());
 }
?>